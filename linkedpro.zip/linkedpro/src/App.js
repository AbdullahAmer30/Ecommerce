import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Main from './Component/main';
import Login from './Component/Login';
import Footer from './Component/Footer';
import Navbars from './Component/Navbar';
import TokenModal from './Component/TokenModal';

const App = () => {
  const [token,setToken]=useState(null)
  const [modal, setModal] = useState(false);

  useEffect(()=>{
setToken(localStorage.getItem('token'))
  },[])
  

  const openModal = () => {
    setModal(true);
    console.log("Modal opened");
  };

  const closeModal = () => {
    setModal(false);
  };

  return (
    <Router>
      <Routes>
        <Route path="/" element={token ? <Main /> : <Navigate to="/login" />} />
        <Route path="/login" element={!token ? <Login setModal={openModal} /> : <Navigate to="/" />} />
      </Routes>
      {modal && <TokenModal show={modal}closeModal={closeModal} />}
      <Footer />
    </Router>
  );
};

export default App;
