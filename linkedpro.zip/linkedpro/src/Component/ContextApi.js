// // TokenContext.js
// import React, { createContext, useContext,useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';

// const TokenContext = createContext();

// export const TokenProvider = ({ children }) => {
//     const [password, setPassword] = useState('');
//     const [error, setError] = useState('');
//     const [loading, setLoading] = useState(false);  
//     const API_URL = 'https://leadsfizz.api-apx.com/api/v1/GetBasicData';
    
  

//     return (
//         <TokenContext.Provider value={{ setWithExpiry, getWithExpiry,PostRequest ,API_URL

//       //  login


//         }}>
//             {children}
//         </TokenContext.Provider>
//     );
// };

// export const useToken = () => useContext(TokenContext);
