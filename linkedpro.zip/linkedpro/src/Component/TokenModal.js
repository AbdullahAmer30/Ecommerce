import React from 'react';
import { Modal, Button } from 'react-bootstrap';

function TokenModal({ show,closeModal }) {
  return (
    <Modal show={show} onHide={closeModal} centered>
      <Modal.Header closeButton>
        <Modal.Title>Token Generation Options</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p><strong>a) Install Our Chrome Extension</strong></p>
        <p>
          Click Here To Install Our Extension <a href="#" target="_blank">LinkedPro</a> and Proceed With It
        </p>
        <p className="text-center"><strong>OR</strong></p>
        <p><strong>b) Connect Manually</strong></p>
        <p>You can connect to LinkedIn Manually With The Following Steps:</p>
        <ol>
          <li>Visit <a href="https://www.linkedin.com" target="_blank">LinkedIn.com</a></li>
          <li>Login to your LinkedIn account</li>
          <li>Press <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>i</kbd> or <kbd>F12</kbd></li>
          <li>Inspect Window Will Be Opened. From there, go to the "Application" tab</li>
          <li>Click on "Cookies" tab</li>
          <li>Click On "https://www.linkedin.com/" sub-tab</li>
          <li>Look for the value with name "li_at"</li>
          <li>Copy the contents from "Cookie Value" section</li>
          <li>Paste The Content Copied in "Login Token" Input</li>
        </ol>
      </Modal.Body>
      <Modal.Footer>
        {/* <Button variant="secondary" onClick={closeModal}>
          Close
        </Button> */}
      </Modal.Footer>
    </Modal>
  );
}

export default TokenModal;
