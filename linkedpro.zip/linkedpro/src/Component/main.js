import React, { useEffect, useState } from 'react';
import { Container, Form, Row, Col,Card,Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import data from '../data.json';
import Cards from './Card';
import Navbars from './Navbar';
import Loader from './loader'; 
import CardBody from './CardBody';

import { PostRequest, getWithExpiry, API_URL, setWithExpiry } from '../utils/globalfunctions';
import '../App.css';
import { GetBasicData,GetCradentialData,GetMainData } from '../utils/apicalls';

const Main = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [loadingapi, setLoadingapi] = useState(false);
    const [query,setQuery]=useState('')
    const [apimain,setmainApi]=useState({})
    const [people,setPeople]=useState(null)
    const [company,setCompany]=useState(null)
    const [product,setProduct]=useState(null)
    // const [showMorePeople, setShowMorePeople] = useState(false);
    // const [showMoreCompanies, setShowMoreCompanies] = useState(false);
    // const [showMoreProducts, setShowMoreProducts] = useState(false);
    let apiData;
    const follow='Follow';
    const Connect='Connect';
    const view='View Page';
        const fetchData = async () => {
    //    debugger
        const token = getWithExpiry('token');
        // const itemStr= localStorage.getItem('Data');
        // const item = JSON.parse(itemStr);
        if (token) {
            const getVal = JSON.parse(localStorage.getItem('Tdta'));
            const storedData = JSON.parse(localStorage.getItem('Data'));
            if(getVal.type=='token'){
             apiData = await GetBasicData(storedData);
            console.log('api',apiData)
            }
            
            else{
               apiData = await GetCradentialData(storedData);
            }
        
            if (!apiData) {
                
                setLoading(false);  
                localStorage.removeItem('token');
                localStorage.removeItem('Data');
                localStorage.removeItem('company');
            localStorage.removeItem('people');
            localStorage.removeItem('product');
                window.location.href = '/login';
            } else {
                
                // console.log()
                setLoading(false);  
                setWithExpiry('token', token, 518400000); 
            }
        } else {
            setLoading(false);  
            localStorage.removeItem('token');
            localStorage.removeItem('Data');
            localStorage.removeItem('token');
            localStorage.removeItem('company');
            localStorage.removeItem('people');
            localStorage.removeItem('product');
            window.location.href = '/login';
        }
    };

    // const getMainData= async()=>{

    //     const tk=JSON.parse(localStorage.getItem('token'))
    //     console.log(tk.value,"valueTOken")
    //     console.log(query,'query')
    //     const Data={
    //         keyword:query,
    //         li_at:'AQEDATAvqq0BxVcXAAABkbx3SHQAAAGR4IPMdE0AyJOHLrKlzDfKAes8a2WZroDnA1IWurRYkExJMh2SarMQeElgmqcCO53H6LTHiJDnT0dE4m2bPHPoylY5HvJPKElVD57ri4blc19JaGhSiCRrKm-s'
    //     }

    //    const api= await GetMainData(Data);
    //    console.log(api,'main api data');
    //    setmainApi(api);
        
    // }
    // let b=[];
    const getMainData = async () => {
        const tk = JSON.parse(localStorage.getItem('token'));
        console.log(tk?.value, "valueTOken");  
        // console.log()
        const Data = {
            keyword: query,
            li_at: tk.value
        };
    

        setLoading(true);  
        // setLoadingapi(true); 
        const api = await GetMainData(Data);
        // console.log(api, 'main api data');
        // const parsedta=JSON.stringify(api)
        // b.push(api.data);
        // console.log("b",b);
        console.log(api,'api main')
        // const combinedData = [...data.people, ...data.company, ...data.product];
        setmainApi(api);
        // console.log(apimain,'check api dta')
        setLoading(false);  
        // setLoadingapi(false); 
    };
    

    useEffect(() => {
        fetchData();
        // getMainData();
    }, []);
    // useEffect(() => {
    //     console.log(apimain, 'Updated API data');
        
        
       

    //         // setPeople(apimain.data.peoples || []);  
    //         // setCompany(apimain.data.companies || []);
    //         // setProduct(apimain.data.products || []);
    //         localStorage.setItem('people',JSON.stringify(apimain.data.peoples));
    //         localStorage.setItem('company',JSON.stringify(apimain.data.companies));
    //         localStorage.setItem('product',JSON.stringify(apimain.data.products));
    //         const storedPeople = localStorage.getItem('people');
    //         const storedCompany =localStorage.getItem('company') ;
    //         const storedProduct = JSON.parselocalStorage.getItem('product' );
    //     //     setPeople(storedPeople );  
    //     // setCompany(storedCompany);
    //     // setProduct(storedProduct );
        
    //     setPeople( storedPeople);  
    //     setCompany(storedCompany);
    //     setProduct(storedProduct);
    //     console.log(people, 'Updated API people');
    //     console.log(company, 'Updated API company');
    //     console.log(product, 'Updated API product');
        
    
        
    // }, [apimain]);

    useEffect(() => {
        if (apimain && apimain.data) {
            
            localStorage.setItem('people', JSON.stringify(apimain.data.peoples ));
            localStorage.setItem('company', JSON.stringify(apimain.data.companies ));
            localStorage.setItem('product', JSON.stringify(apimain.data.products ));
            
        }
        
        const storedPeople = localStorage.getItem('people');
        const storedCompany = localStorage.getItem('company');
        const storedProduct = localStorage.getItem('product');
        
       
        setPeople(JSON.parse(storedPeople) );  
        setCompany(JSON.parse(storedCompany) );
        setProduct(JSON.parse(storedProduct) );
    }, [apimain]);
    
  
   
    return (
        <>
            {loading&&<Loader show={loading}/> } 
            <Navbars />
            <div className='cont'>
                <Container>
                    <Form className='d-flex'>
                        <div className="search-input-wrapper">
                            <i className="fas fa-search search-icon"></i>
                            <Form.Control 
                                type="text" 
                                placeholder="Search" 
                                className='inputbg' 
                                value={query} 
                                onChange={(e) => setQuery(e.target.value)}
                            />
                        </div>
                        <Button 
                            className="search-input-wrapper" 
                            onClick={getMainData}  
                            disabled={loadingapi}  
                        >
                            {loadingapi ? "Searching..." : "Search"}  
                        </Button>
                    </Form>
    
                    <Row>
                    {people&&company&&product&&people.length === 0 && company.length === 0 && product.length === 0 && (
                            <Col xs={12}>
                                <div className='result d-flex mt-4'>
                                <h4>No results found</h4>
                                </div>
                                 
                               
                            </Col>
                            )}
                    {people && people.length > 0 && (
                        <Col xs={12} sm={6} md={6} lg={6}>
                            <Card className=" w-100  p-2 cardSize">
                                <h3>People</h3>
                                {people.map((person) => (
                                    <CardBody  arr={person} button={Connect} />
                                ))}
                                    
                              
                               
                            </Card>
                        </Col>
                    )}

                    {company && company.length > 0 && (
                        <Col xs={12} sm={6} md={6} lg={6}>
                            <Card className="  w-100  p-2 cardSize">
                                <h3>Companies</h3>
                                {company.map((comp) => (
                                    <CardBody  arr={comp} button={follow} />
                                ))}
                                
                               
                            </Card>
                        </Col>
                    )}

                    {product && product.length > 0 && (
                        <Col xs={12} sm={6} md={6} lg={6}>
                            <Card className="mt-2 w-100  p-2 cardSize">
                                <h3>Products</h3>
                                {product.map((prod) => (
                                    <CardBody  arr={prod} button={view}  />
                                ))}
                               
                            </Card>
                        </Col>
                    )}
                
                    </Row>
                </Container>
            </div>
        </>
    );
    
};

export default Main;

