import React,{useState} from 'react';
import { Navbar, Container, Nav } from 'react-bootstrap';
import { Navigate, NavLink, useNavigate } from 'react-router-dom';
import logoutIcon from '../images/logout.png';
import homeIcon from '../images/homeIcon.png'; 
import peopleIcon from '../images/peopleIcon.png';
import suitcaseIcon from '../images/suitcaseIcon.png';
import notification from '../images/notification.png';
import chatIcon from '../images/chatIcon.png';
import linkedInLogonew from '../images/linkedInLogoNew.png';
import '../styles/Navbar.css';
import Loader from './loader';
const Navbars = () => {
  const navigate=useNavigate()
  const [loading, setLoading] = useState(false); 
  // const logout=()=>{
  //   localStorage.removeItem('Data')
  //   localStorage.removeItem('Tdta')
  //   localStorage.removeItem('token')
  //   localStorage.removeItem('people')
  //   localStorage.removeItem('company')
  //   localStorage.removeItem('product')
  //   navigate('/login');
   
  // }
  const logout = () => {
    setLoading(true); 
    setTimeout(() => {
      localStorage.removeItem('Data');
      localStorage.removeItem('Tdta');
      localStorage.removeItem('token');
      localStorage.removeItem('people');
      localStorage.removeItem('company');
      localStorage.removeItem('product');
      navigate('/login'); 
      setLoading(false); 
      
    }, 2000);
  };

  return (
    <>
      {loading && <Loader show={loading} />} 
      <Navbar expand="lg" className="navb">
        <Container className="navbars">
          <Navbar.Brand href="#home">
            <span className="logoName">Linked</span>
            <img src={linkedInLogonew} width="30" height="30" alt="Logo" className="logoImg" />
          </Navbar.Brand>
          <Navbar.Toggle className="toggle" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="ms-auto d-flex justify-content-between nav-item">
              <NavLink className="items" to="/">
                <div className="icon-container">
                  <img src={homeIcon} width="24" height="24" alt="Home" />
                  <span className="icon-label">Home</span>
                </div>
              </NavLink>
              <NavLink className="items" to="/people">
                <div className="icon-container">
                  <img src={peopleIcon} width="24" height="24" alt="People" />
                  <span className="icon-label">People</span>
                </div>
              </NavLink>
              <NavLink className="items" to="/jobs">
                <div className="icon-container">
                  <img src={suitcaseIcon} width="24" height="24" alt="Jobs" />
                  <span className="icon-label">Jobs</span>
                </div>
              </NavLink>
              <NavLink className="items" to="/messaging">
                <div className="icon-container">
                  <img src={chatIcon} width="24" height="24" alt="Messaging" />
                  <span className="icon-label">Messaging</span>
                </div>
              </NavLink>
              <NavLink className="items" to="/notifications">
                <div className="icon-container">
                  <img src={notification} width="25" height="25" alt="Notifications" />
                  <span className="icon-label">Notifications</span>
                </div>
              </NavLink>
              <div className="items" onClick={logout}>
                <div className="icon-container">
                  <img src={logoutIcon} width="25" height="25" alt="Logout" />
                  <span className="icon-label">Logout</span>
                </div>
              </div>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </>
  );
};

export default Navbars;
