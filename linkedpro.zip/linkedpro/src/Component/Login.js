// import React, { useState, useEffect } from 'react';
// import { Form, Button, InputGroup, Container, Row, Col } from 'react-bootstrap';
// import '../styles/Login.css'; 
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// // import { Navigate } from 'react-router-dom'; 
// function Login() {
//     const [isChecked, setIsChecked] = useState(false);
//     const [email, setEmail] = useState('');
//     const [password, setPassword] = useState('');
//     const [error, setError] = useState('');
//     const [redirect, setRedirect] = useState(false);
//     const API_URL = 'https://leadsfizz.api-apx.com/api/v1/GetBasicData';
// //   alert("1");    
// const navigate=useNavigate();
//     const setWithExpiry = (key, value, ttl) => {
//         const now = new Date();
//         const item = {
//             value: value,
//             expiry: now.getTime() + ttl,
//         };
//         localStorage.setItem(key, JSON.stringify(item));
//     };


//     const getWithExpiry = (key) => {
//         // debugger
//         const itemStr = localStorage.getItem(key);

//         if (!itemStr) {
//             return null;
//         }

//         const item = JSON.parse(itemStr);
//         const now = new Date();

//         if (now.getTime() > item.expiry) {
//             console.log("expirre")
//             localStorage.removeItem(key);
//             localStorage.setItem(key, null);
//             return null;
//         }

//         return item.value;
//     };

//     const PostRequest = async (RawData, EndPoint) => {
//         try {

//             const response = await axios.post(EndPoint, RawData, {
//                 headers: {
//                     'Content-Type': 'application/json',
//                 }
//             });

//             const result = JSON.stringify(response.data);

//             if (result != null) { 
//                 setWithExpiry('token', result, 60 * 1000);
//                 setRedirect(true); 
//             } else {
//                 setError('Failed to sign in');
//             }
//         } catch (error) {
//             setError('An error occurred. Please try again.');
//         }
//     };

//     const handleToggleChange = () => {
//         setIsChecked(!isChecked);
//     };

//     const handleSubmit = (event) => {
//         event.preventDefault();

//         const RawData = {
//             SearchQuery: "Pakistan",
//             DataType: "Country",
//             Search_Token: password,
//         };

//         PostRequest(RawData, API_URL);
//     };

//     useEffect(() => {
//         console.log("Alertw");
//         const token = getWithExpiry('token');
//         console.log("console")
//         if (token) {


//             return window.location.href="/"; 

//         }
//         else
//         {
//             navigate("/login");
//         }

//     }, [redirect]);



//     return (
//         <Container className="d-flex justify-content-center align-items-center min-vh-100">
//             <Row className="w-100">
//                 <Col xs={12} sm={8} md={6} lg={4} className="mx-auto">
//                     <div className="signin-box p-4 rounded shadow-md">
//                         <div className="mb-4 d-flex justify-content-between align-items-center">
//                             <h2>Linked<span className="text-primary">in</span></h2>
//                             <div className="custom-switch-container">
//                                 <label className="custom-switch">
//                                     <input 
//                                         type="checkbox" 
//                                         id="manualSwitch" 
//                                         checked={isChecked} 
//                                         onChange={handleToggleChange}
//                                     />
//                                     <span className="slider"></span>
//                                     <span className={`switch-text ${isChecked ? 'auto' : 'manual'}`}>
//                                         {isChecked ? 'Auto' : 'Manual'}
//                                     </span>
//                                 </label>
//                             </div>
//                         </div>
//                         <h1>Sign in</h1>
//                         <p className="text-muted">Stay updated on your professional world</p>

//                         {error && <p className="text-danger">{error}</p>} 

//                         <Form onSubmit={handleSubmit}>
//                             <Form.Group className="mb-3">
//                                 <Form.Control 
//                                     type="email" 
//                                     placeholder="LinkedIn Login Email" 
//                                     value={email}
//                                     onChange={(e) => setEmail(e.target.value)}
//                                     required
//                                 />
//                             </Form.Group>

//                             <Form.Group className="mb-3">
//                                 <InputGroup>
//                                     <Form.Control 
//                                         type="password" 
//                                         placeholder="Password" 
//                                         value={password}
//                                         onChange={(e) => setPassword(e.target.value)}
//                                         required
//                                     />
//                                     <InputGroup.Text>
//                                         <i className="bi bi-eye"></i>
//                                     </InputGroup.Text>
//                                 </InputGroup>
//                             </Form.Group>
//                             <div className='d-flex justify-content-center'>
//                                 <Button type="submit" className="w-50 d-flex justify-content-center btn">
//                                     SIGN IN
//                                 </Button>
//                             </div>
//                         </Form>
//                     </div>
//                 </Col>
//             </Row>
//         </Container>
//     );
// }

import React, { useState, useEffect } from 'react';
import { Form, Button, InputGroup, Container, Row, Col } from 'react-bootstrap';
import '../styles/Login.css';
import axios, { formToJSON } from 'axios';
import { useNavigate } from 'react-router-dom';

import questionmark from '../images/questionmark.png';
import linkedInLogo from '../images/linkedInLogo.png';
// import { getWithExpiry, PostRequest, setWithExpiry } from "./globelFunction"
import { getWithExpiry, PostRequest, setWithExpiry, API_URL, checkapi,EncryptVal } from '../utils/globalfunctions';
import { GetBasicData, GetCradentialData } from '../utils/apicalls';
import { kdf } from 'crypto-js';


function Login({ setModal }) {
    const [isChecked, setIsChecked] = useState(false);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [loginToken, setLoginToken] = useState('')
    const [error, setError] = useState('');
    const [emailError, setEmailError] = useState('');

    // const [redirect, setRedirect] = useState(false);
    const [loading, setLoading] = useState(false);
    // const API_URL = 'https://leadsfizz.api-apx.com/api/v1/GetBasicData';

    const navigate = useNavigate();


    const handleToggleChange = () => {
        setIsChecked(!isChecked);
    };

//     const handleSubmit = async (event) => {
//         // debugger
//         event.preventDefault();
//         setLoading(true);

//         // alert("1");
//         // const RawData = JSON.stringify({
//         //     SearchQuery: "Pakistan",
//         //     DataType: "Country",
//         //     Search_Token: loginToken,
//         // });

//         const RawData = JSON.stringify(
//             isChecked
//                 ? {
//                     SearchQuery: "Pakistan",
//                     DataType: "Country",
//                     Search_Token: loginToken,
//                 }
//                 : {
//                     userName:EncryptVal(email),
//                     userPassword: EncryptVal(password),
//                     userID: EncryptVal(""),
//                 }
//         );




//         localStorage.setItem('Data', RawData);
// debugger
//         let api_data = isChecked ? await GetBasicData(RawData) : await GetCradentialData(RawData);

//         console.log("api_data: ", api_data)
//         if (api_data != null) {
//             // localStorage.setItem('Data', RawData);
//             const Tdta = {
//                 email: email,
//                 paswsord: isChecked ? loginToken : password,
//                 type: isChecked ? 'token' : 'password'
//             }
//             localStorage.setItem('Tdta', JSON.stringify(Tdta));
//             console.log("apiData:",api_data)
//             // checkapi('token', password, 60 * 1000,setLoading);
//             setWithExpiry('token', isChecked ? loginToken : password, 518400000);
//             // setRedirect(true); 
//             setLoading(false);
//             window.location.href = '/';

//         } else {
//             localStorage.removeItem('token');
//             // localStorage.removeItem('Data');
//             setError('Failed to sign in');
//             setLoading(false);
//             navigate("/login");

//         }
//     };

const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+\@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

const handleSubmit = async (event) => {
    event.preventDefault();
    if (!validateEmail(email)) {
        setEmailError('Please enter a valid email address.');
        return;
      }
    setLoading(true);

    const RawData = JSON.stringify(
        isChecked
            ? {
                SearchQuery: "Pakistan",
                DataType: "Country",
                Search_Token: loginToken,
            }
            : {
                userName: EncryptVal(email),
                userPassword: EncryptVal(password),
                userID: EncryptVal(""),
            }
            
    );
    localStorage.setItem('Data', RawData);
    let api_data = isChecked ? await GetBasicData(RawData) : await GetCradentialData(RawData);
    
    // debugger
    if (!api_data || api_data.Status=="Invalid_Credentials") {
        setError( 'Failed to sign in');
        setLoading(false);
        navigate("/login");
    } else {
        
       
        const Tdta = {
            email: email,
            paswsord: isChecked ? loginToken : password,
            type: isChecked ? 'token' : 'password'
        };
        localStorage.setItem('Tdta', JSON.stringify(Tdta));
        setWithExpiry('token', isChecked ? loginToken : password, 518400000);
        setLoading(false);
        window.location.href = '/';
    }
};


    return (
        <Container className="d-flex justify-content-center align-items-center min-vh-100">
            <Row className="w-100">
                <Col xs={12} sm={8} md={6} lg={4} className="mx-auto">
                    <div className="signin-box p-4 rounded shadow-md">
                        <div className="mb-4 d-flex justify-content-between align-items-center">
                            <h2>Linked<img className="LinkedinIcon" src={linkedInLogo} alt="LinkedIn Logo" /></h2>
                            <div className="custom-switch-container">
                                <label className="custom-switch">
                                    <input
                                        type="checkbox"
                                        id="manualSwitch"
                                        checked={isChecked}
                                        onChange={handleToggleChange}
                                    />
                                    <span className="slider"></span>
                                    <span className={`switch-text ${isChecked ? 'auto' : 'manual'}`}>
                                        {isChecked ? 'Auto' : 'Manual'}
                                    </span>
                                </label>
                                {isChecked && (
                                    <span>
                                        <img
                                            className="questionIcon"
                                            src={questionmark}
                                            alt="Question Mark Icon"
                                            onClick={setModal}
                                        />
                                    </span>
                                )}
                            </div>
                        </div>
                        {!isChecked ? (
                            <h1>Sign in</h1>
                        ) : (
                            <h4>Password Less <h6>Sign-in</h6></h4>
                        )}
                        <p className="text-muted">Stay updated on your professional world</p>

                        {error && <p className="text-danger">{error}</p>}

                        <Form onSubmit={handleSubmit}>
                            {/* <Form.Group className="mb-3">
                                <Form.Control
                                    type="email"
                                    placeholder="LinkedIn Login Email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                />
                            </Form.Group> */}
 <Form.Group className="mb-3">
        <Form.Control
          type="email"
          placeholder="LinkedIn Login Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          isInvalid={emailError!==''}
          required
        />
        <Form.Control.Feedback type="invalid">
          {emailError}
        </Form.Control.Feedback>
      </Form.Group>
                            <Form.Group className="mb-3">
                                <InputGroup>
                                    <Form.Control
                                        type={!isChecked?(showPassword ? "text" : "password"):'text'}
                                        placeholder={isChecked ? "Login Token" : "Password"}
                                        value={isChecked ? loginToken : password}
                                        onChange={(e) => { isChecked ? setLoginToken(e.target.value) : setPassword(e.target.value) }}
                                        required
                                    />
                                    {!isChecked &&<InputGroup.Text onClick={() => setShowPassword(!showPassword)}>
                                        <i className={`bi bi-eye${showPassword ? '-slash' : ''}`}></i>
                                    </InputGroup.Text>}
                                    
                                </InputGroup>
                            </Form.Group>
                            <div className='d-flex justify-content-center'>
                                <Button
                                    type="submit"
                                    className="w-50 d-flex justify-content-center btn"
                                    disabled={loading}
                                >
                                    {loading ? "Signing In..." : "SIGN IN"}
                                </Button>
                            </div>
                        </Form>
                    </div>
                </Col>
            </Row>
        </Container>
    );
}

export default Login;
