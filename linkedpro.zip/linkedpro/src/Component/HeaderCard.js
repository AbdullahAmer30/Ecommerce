import React from 'react'
import { Container, Form ,Card,Row,Col, Button } from 'react-bootstrap';
import '../styles/headerCard.css'
const HeaderCard = ({item}) => {
  return (
    <>
    <div className='headerSection mb-3'>{item.category}</div>
    <div className='d-flex  btnstyle'>
      {item.list.map((lst)=>(<Button className='me-2 w-40 d-flex buttons justify-content-center align-items-center rounded-pill'>
    <span>{lst}</span>
    </Button>))}
  
    {/* <Button className='me-2 w-40 d-flex buttons justify-content-center align-items-center rounded-pill'>
    dededededd
    </Button>
    <Button className='me-2 w-40 d-flex buttons justify-content-center align-items-center rounded-pill'>
    ded
    </Button> */}

  </div> 
  </>
  )
}

export default HeaderCard