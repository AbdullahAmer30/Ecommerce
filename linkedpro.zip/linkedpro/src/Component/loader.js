import React from 'react';
import '../styles/Loader.css'; 

const Loader = ({ show }) => {
    if (!show) return null;

    return (
        <div className="loader-modal">
            <div className="loader">
                <div className="circle"></div>
                <div className="circle"></div>
                <div className="circle"></div>
            </div>
        </div>
    );
};

export default Loader;
