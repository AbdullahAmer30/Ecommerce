// // globelFunction.js
// import axios from 'axios';

// // export const API_URL = 'https://leadsfizz.api-apx.com/api/v1/GetBasicData';

// export const setWithExpiry = (key, value, ttl) => {
//     const now = new Date();
//     const item = {
//         value: value,
//         expiry: now.getTime() + ttl,
//     };
//     localStorage.setItem(key, JSON.stringify(item));
// };

// // export const checkapi=(tokn,pass,time,setLoading)=>{
// //     setWithExpiry(tokn, pass, time);
// //     // setRedirect(true); 
// //     // setLoading(false);
// //     // setWithExpiry('token', password, 60 * 1000);
// //     window.location.href='/';
// // }
// export const getWithExpiry = (key) => {
//     const itemStr = localStorage.getItem(key);
//     console.log('getdata :',itemStr)
//     if (!itemStr) return null;
//     // console.log('getdata :',itemStr)
//     const item = JSON.parse(itemStr);
//     console.log('getdata :',item.value)
//     const now = new Date();

//     if (now.getTime() > item.expiry) {
//         localStorage.removeItem(key);
//         return null;
//     }

//     return item.value; 
// };


