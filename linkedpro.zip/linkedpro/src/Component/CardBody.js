import React from 'react';
import { Container, Form, Card, Row, Col, Button } from 'react-bootstrap';
import '../styles/cardBody.css';
import mutuals from '../images/audience.png';
import recruitment from '../images/recruitment.png';
import linkedIn from '../images/linkedin.png';
import Briefcase from '../images/briefcase.png';
import { getMainApi } from '../utils/endpints';

function CardBody({ arr,button }) {
  return (
    <Card.Body className='cardBody'>

      <Row className='g-4 justify-content-center classRow'>
        <Col xs={12} sm={6} md={6} lg={2}>
    {arr.profileImage&& <Card.Img variant="top" src={arr.profileImage
 } className='rounded-circle cardImg' />}
 {arr.profiePicture&& <Card.Img variant="top" src={arr.profiePicture} className='rounded-circle cardImg' />}
        </Col>
        <Col xs={12} sm={6} md={6} lg={6}>
          <Card.Text className='cardText'>
            <div className='maindv'>
              <p className='PCname'>{arr.name}</p>
              <p className='ProductName'>{arr.productName}</p>
              {arr.subtitle && <p className='expertise'> {arr.subtitle.split(' ').length > 10
      ? arr.subtitle.split(' ').slice(0, 10).join(' ') + '....' 
      : arr.subtitle}</p>}
              {/* {arr.expertise && arr.expertise.map((exp, i) => <p key={i} className='expertise'>{exp} </p>)} */}
<div className='lmfdiv'> {arr.summary && (
  <p className='mutual'>
    {arr.summary.split(' ').length > 10
      ? arr.summary.split(' ').slice(0, 10).join(' ') + '....' 
      : arr.summary}
  </p>
)}
{/* {arr.summary&&<p>{arr.secondarySubti}</p>} */}
              {arr.secondarySubtitle && <p className='locationText'>{arr.secondarySubtitle}</p>}
              {arr.followers && <p className='followers'>{arr.followers}</p>}  </div>
             
              
              {/* {arr.Recuitment && <p className='Recuitment'><img src={recruitment} className='recImg' />{arr.Recuitment}</p>} */}
              {/* {arr.mutuals && <p className='mutual'><img src={mutuals} className='mutualImg' />{arr.mutuals.map((exp, i) => <span key={i}>{exp}</span>)}</p>} */}
              {/* {arr.apply && <p className='apply'>{arr.apply}. <img src={linkedIn} className='linkedInImg' />Easy apply</p>} */}
              {/* {arr.description && <p className='description'>{arr.description}</p>} */}
            </div>
          </Card.Text>
        </Col>
        <Col xs={12} sm={6} md={12} lg={4}>
          <div className='cardBodyBtn'>
           
            <button className='connectBtn rounded-pill btnTextColor'>
            {/* <a href={arr.profileLink} > */}
{button}
  
              
            </button>  
            
          </div>
        </Col>
        <hr />
      </Row>

      {/* <a href='#'><p className='text-center'>{item.selection}</p></a> */}
    </Card.Body>
  )
}

export default CardBody;
