// import React, { useEffect, useState } from 'react'
// import data from '../data.json'
// import { Container, Form, Card, Row, Col, Button } from 'react-bootstrap';
// import HeaderCard from './HeaderCard';
// import CardBody from './CardBody';
// import '../styles/Card.css'
// const Cards = ({ item }) => {
//   const [newArr, setArr] = useState([])
  

//   const filteredArr = () => {
//     return data.info.filter((dta) => item.category === dta.category);
//   }
//   useEffect(() => {
//     setArr(filteredArr())
//   }, [])
//   // setArr(filteredArr)
//   // console.log(newArr,"filtered")
//   console.log(item,"item")
//   return (
//     <Card  className="w-100  p-2 cardSize">
      
     
//       <HeaderCard item={item}/>

//       <CardBody filteredArr={newArr} item={item}/>
//     </Card>

//   )
// }

// export default Cards;