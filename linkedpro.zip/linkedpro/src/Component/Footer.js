import React from 'react'
import linkedInLogonew from  '../images/linkedInLogoNew.png';
import '../styles/Footer.css';
const Footer = () => {
  return (
    <div>
        <footer class="footer-col text-white mt-5 p-4 text-center">
  <div class="container">
    <div class="row">
      <div class="col-md-4 mt-4">
        <img className='logolinkedin' src={linkedInLogonew}/>
        <p>We are a company dedicated to providing the best services to our customers.</p>
      </div>
      <div class="col-md-4 mb-3">
        <h5>Contact Us</h5>
        <ul class="list-unstyled">
          <li>Email: info@linkedIn.com</li>
          <li>Phone: +92 234 567 890</li>
          <li>Address: Plaza 135 Zenith Innovations, Islamabad, Pakistan</li>
        </ul>
      </div>
      <div class="col-md-4 mb-3">
        <h5>Follow Us</h5>
        <a href="#" class="text-white me-2"><i class="bi bi-facebook"></i></a>
        <a href="#" class="text-white me-2"><i class="bi bi-twitter"></i></a>
        <a href="#" class="text-white"><i class="bi bi-linkedin"></i></a>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <p class="mb-0">&copy; 2024 LinkedIn. All Rights Reserved.</p>
      </div>
    </div>
  </div>
</footer>

    </div>
  )
}

export default Footer