const baseurl1="https://leadsfizz.api-apx.com/api/v1"
const baseurl2="https://leadsfizz.api-apx.com/api/v2"
const baseurl3="https://linkedpro.api-apx.com/api/Task3"

export const BasicData_Endpoint=baseurl1+"/GetBasicData";
export const Cradential_Endpoint=baseurl2+"/AuthenticatingUserWidget";

// export const mainDta_Endpoint=baseurl3+"/linkedin?keyword=ZENITH&li_at=AQEDATaltloA4ErNAAABkaGTd6kAAAGRxZ_7qU0ACb3KWS050M4MiUM0xi0Hq0M7TXTrzBx85g86mau_ZvfxIdLuYZjXS-BvbnOPvUi525Tov9xWKz1yb7ttRhjGfp0WuNJYz7EtDDCuK2Mt2wlhivA2"

 export const getMainApi=(body)=>{
    // const dta=JSON.parse(body)
    let mainDta_Endpoint=baseurl3+`/linkedin?keyword=${body.keyword}&li_at=${body.li_at}`
    return mainDta_Endpoint;
 }