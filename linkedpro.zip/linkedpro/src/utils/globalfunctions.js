
import axios from 'axios';
import CryptoJS from "crypto-js";
// export const API_URL = 'https://leadsfizz.api-apx.com/api/v1/GetBasicData';

const Key_val = CryptoJS.enc.Utf8.parse("8080808080808080");
const IV_val = CryptoJS.enc.Utf8.parse("8080808080808080");

export const EncryptVal = (value_to_be_ecrypt) => {
    var encrypted_Val = CryptoJS.AES.encrypt(
      CryptoJS.enc.Utf8.parse(value_to_be_ecrypt),
      Key_val,
      {
        iv: IV_val,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      }
    );
  
    return encrypted_Val.toString();
  };
  
  export const DecryptVal = (value_to_be_decrypt) => {
    var decrypted_Val = CryptoJS.AES.decrypt(value_to_be_decrypt, Key_val, {
      iv: IV_val,
    });
    var originalText = decrypted_Val.toString(CryptoJS.enc.Utf8);
    return originalText;
  };

export const setWithExpiry = (key, value, ttl) => {
    const now = new Date();
    const item = {
        value: value,
        expiry: now.getTime() + ttl,
    };
    console.log(item.value,"valueeee")
    localStorage.setItem(key, JSON.stringify(item));
};

// export const checkapi=(tokn,pass,time,setLoading)=>{
//     setWithExpiry(tokn, pass, time);
//     // setRedirect(true); 
//     // setLoading(false);
//     // setWithExpiry('token', password, 60 * 1000);
//     window.location.href='/';
// }
export const getWithExpiry = (key) => {
    const itemStr = localStorage.getItem(key);
    console.log('getdata :',itemStr)
    if (!itemStr) return null;
    // console.log('getdata :',itemStr)
    const item = JSON.parse(itemStr);
    console.log('getdata :',item.value)
    const now = new Date();

    if (now.getTime() > item.expiry) {
        localStorage.removeItem(key);
        return null;
    }

    return item.value; 
};


