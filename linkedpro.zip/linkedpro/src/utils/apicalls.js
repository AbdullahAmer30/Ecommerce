import axios from "axios";
import { BasicData_Endpoint,Cradential_Endpoint ,mainDta_Endpoint,getMainApi} from "./endpints";

 const PostRequest = async ( EndPoint,RawData) => {
    try {
        const response = await axios.post(EndPoint,RawData, {
            headers: {
                'Content-Type': 'application/json',
                 
            }
        });
        return response.data;
    } catch (error) {
        return null;
    }
};


export const GetBasicData=(body)=>{

    return PostRequest(BasicData_Endpoint,body);
}


export const GetCradentialData=(body)=>{

    return PostRequest(Cradential_Endpoint,body);
}

export const GetMainData=(body)=>{
let mainEnd= getMainApi(body)
    return PostRequest(mainEnd,body);

}